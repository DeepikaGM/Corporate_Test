<?php
	include('Controller/DBController.php');
	require_once 'View/EmployeeDetails.php';
	$action=$_GET['action'];
	switch($action)
	{
		case "Employee_add":
			if (isset($_POST['btnSubmit'])) {
			$name = $_POST['empname'];
			$Location = $_POST['txtLocation'];
			$dob = "";
			if ($_POST["dob"]) {
				$dob_timestamp = strtotime($_POST["dob"]);
				$dob = date("Y-m-d", $dob_timestamp);
			}
			$Department = $_POST['txtDepartment'];


			 $EmployeeDetails = new EmployeeDetails();
			$insertId = $EmployeeDetails->addEmployee($name, $Location, $dob, $Department);
			if (empty($insertId)) {
				$response = array(
					"message" => "Problem in Adding New Record",
					"type" => "error"
				);
			} else {
				header("Location: Home.php");
			}
		}

		break;

		case "Employee_edit":
			$employee_id = $_GET["id"];
			$EmployeeDetails = new EmployeeDetails();

			if (isset($_POST['btnSubmit'])) {
				$name = $_POST['name'];
				$Department = $_POST['Department'];
				$dob = "";
				if ($_POST["dob"]) {
					$dob_timestamp = strtotime($_POST["dob"]);
					$dob = date("Y-m-d", $dob_timestamp);
				}
				$Location = $_POST['Location'];

				$EmployeeDetails->editemployee($name, $Location, $dob, $Department, $employee_id);

				header("Location: Home.php");
			}

			$result = $EmployeeDetails->getEmployeeById($employee_id);

			break;

		case "Employee_delete":
			$employee_id = $_GET["id"];
			$EmployeeDetails = new EmployeeDetails();

			$EmployeeDetails->deleteEmployee($employee_id);

			$result = $EmployeeDetails->getAllEmployees();
			//require_once "web/student.php";
			break;

		default:
			$EmployeeDetails = new EmployeeDetails();
			$result = $EmployeeDetails->getAllEmployee();
		   // require_once "web/student.php";
			break;

	}
?>