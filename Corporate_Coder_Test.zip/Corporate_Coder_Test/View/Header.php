<!doctype html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Swiper demo</title>
		<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
		<link rel="stylesheet" href="../css/style.css">
		<link rel="stylesheet" href="../css/swiper.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/jquery-1.5.js"></script>
		<script src="../js/jquery.min.js"></script>

		<script src="../js/bootstrap.min.js"></script>
		<script src='https://kit.fontawesome.com/a076d05399.js'></script>
		<script>
			function addEmploy()
			{
				window.location="AddEmployee.php";
			}
			function ConverttoPDF()
			{
				var url = window.location.toString();
				//alert(url);
				window.location="pdffile.php?urldata="+url;
			}
		$(document).ready(function(){

				load_data();

				function load_data(query)
				{

					$.ajax({
					url:"Searchdata.php",
					method:"POST",
					data:{query:query},
					success:function(data)
					{
						$('#result').html(data);
					}
					});
				}
				$('#txtSearch').keyup(function(){
					var search = $(this).val();
					if(search != '')
					{
						load_data(search);
					}
					else
					{
						load_data();
					}
				});

		});
		</script>
		</script>
	</head>
	<body>