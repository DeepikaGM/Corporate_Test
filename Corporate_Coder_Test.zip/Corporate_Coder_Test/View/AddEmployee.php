<?php require_once "Header.php"; ?>

<form name="frmAdd" method="post" action="../EmployeeActions.php?action=Employee_add" id="frmAdd"
    onSubmit="return validate();">
    <div id="mail-status"></div>
    <div class="container">
		<div class="row">
			 <div class="col-md-12">
				<h2 style="font-family:cambria;">Add New Employee</h2>
			 </div>
		</div>
		<div class="divEmployee">
			<div class="row">
				 <div class="col-md-12">
					<label style="padding-top: 20px;">Employee Name : </label>
					<span id="nameinfo" class="info"></span><br />
				 </div>
			</div>
			<div class="row">
				 <div class="col-md-12">
					<input type="text" name="empname" id="empname" class="form-control">
				 </div>
			</div>
			<div class="row">
				 <div class="col-md-12">
					<label style="padding-top: 20px;">Date of Joining : </label>
					<span id="Dateinfo" class="info"></span><br />
				 </div>
			</div>
			<div class="row">
				 <div class="col-md-12">
					<input type="date" name="dob" id="dob" class="form-control">
				</div>
			</div>
			<div class="row">
				 <div class="col-md-12">
					<label style="padding-top: 20px;">Location : </label>
					<span id="Locationinfo" class="info"></span><br />
				 </div>
			</div>
			<div class="row">
				 <div class="col-md-12">
					<input type="text" name="txtLocation" id="txtLocation" class="form-control">
				</div>
			</div>
			<div class="row">
				 <div class="col-md-12">
					<label style="padding-top: 20px;">Department : </label>
					<span id="Departmentinfo" class="info"></span><br />
				 </div>
			</div>
			<div class="row">
				 <div class="col-md-12">
					<input type="text" name="txtDepartment" id="txtDepartment" class="form-control">
				</div>
			</div>
			<br/>
			<div class="row">
				<div class="col-md-4"></div>
				<div class="col-md-4"></div>
				 <div class="col-md-4">
					<input type="submit" name="btnSubmit" id="btnSubmit" value="Add" class="btn" />
				</div>
			</div>
		</div>
    </div>


    </div>
</form>
<script src="https://code.jquery.com/jquery-2.1.1.min.js"
    type="text/javascript"></script>
<script>
function validate() {
    var valid = true;

    if(!$("#empname").val()) {
        $("#nameinfo").html("(required)");
        $("#empname").css('background-color','#FFFFDF');
        valid = false;
    }
    if(!$("#dob").val()) {
        $("#dateinfo").html("(required)");
        $("#dob").css('background-color','#FFFFDF');
        valid = false;
    }
    if(!$("#txtDepartment").val()) {
        $("#departmentinfo").html("(required)");
        $("#txtDepartment").css('background-color','#FFFFDF');
        valid = false;
    }
    if(!$("#txtLocation").val()) {
        $("#Locationinfo").html("(required)");
        $("#txtLocation").css('background-color','#FFFFDF');
        valid = false;
    }
    return valid;
}
</script>
</body>
</html>