<?php require_once "Header.php"; ?>
			 <form id="form1">
            <div class="container-fluid">
            	<div class="row">
            		<div class="col-md-12">
            			<div style="font-family:Cambria;color:White;height:60px;background-color:#3380FF;padding:2px 0px 10px 10px;"><h2 style=""> Employee Details </h2></div>
            		</div>
            	</div>
            	<br/>
				<div class="row">
                    <div class="col-md-4">
                    	<input type="button" name="btnAdd" id="btnAdd" class="btn" value="Add new Employee" onclick="addEmploy()"/>
					</div>
					 <div class="col-md-2"></div>
					 <div class="col-md-2"></div>
					<div class="col-md-4">
						<input type="button" name="btnPDF" id="btnPDF" class="btn" value="Convert to PDF" onclick="ConverttoPDF()"/>
					</div>

				</div>
				<br/>
				<div class="row">
					<div class="col-md-6">
						<div class="search">
						<form class="search-form">
							<input type="text" id="txtSearch" name="txtSearch" List="datalist1" placeholder="Filter by Employee name,Date,Location">
								<datalist id="datalist1">
									<option value="Employeename">
									<option value="Date">
									<option value="Location">
								</datalist>
								<input type="button" class="btn" value="Search" id="btnSearch" onclick="GetData()">

						</form>
						</div>
					</div>
					<div class="col-md-6">
					</div>
				</div>
				<hr/>
				<div class="row">
					<div class="col-md-12">
						 <table class="table table-hover">
						    <thead>
						      <tr>
						        <th>Empname</th>
						        <th>DOB</th>
						        <th>Location</th>
						        <th>Department</th>
						        <th>Edit</th>
						        <th>Delete</th>
						      </tr>
						    </thead>
						    <tbody>
						      <tr>
						        <td>Priyanka</td>
						        <td>12-03-2016</td>
						        <td>Chennai</td>
						        <td>Sales</td>
						        <td><a class="btnEditAction"
                       href="EditEmployee.php?id=1&name=Priyanka&loc=Chennai&Dept=Sales&date=12-03-2016">
                        <i class='fas fa-edit' style='font-size:24px'></i>
                        </a></td>
						        <td><a class="btnDeleteAction"
                        href="EmployeeActions.php?action=Employee_Delete&id=<?php echo $result[$k]["id"]; ?>">
                        <i class='fas fa-trash' style='font-size:24px'></i>
                        </a></td>
						      </tr>
						      <tr>
						        <td>Sushant</td>
						        <td>20-01-2017</td>
						        <td>Mumbai</td>
						        <td>IT</td>
						        <td><a class="btnEditAction"
								href="EditEmployee.php?id=2&name=Sushant&loc=Mumbai&Dept=IT">
								<i class='fas fa-edit' style='font-size:24px'></i>
                        		</a></td>

						        <td><a class="btnDeleteAction"
								href="EmployeeActions.php?action=Employee_Delete&id=<?php echo $result[$k]["id"]; ?>">
								<i class='fas fa-trash' style='font-size:24px'></i>
                        		</a></td>
						      </tr>
						      <tr>
						        <td>Riya</td>
						        <td>02-10-2019</td>
						        <td>Mumbai</td>
						        <td>IT</td>
						        <td><a class="btnEditAction"
								href="EditEmployee.php?id=3&name=Riya&loc=Mumbai&Dept=IT">
								<i class='fas fa-edit' style='font-size:24px'></i>
                        		</a></td>
						        <td><a class="btnDeleteAction"
								href="EmployeeActions.php?action=Employee_Delete&id=<?php echo $result[$k]["id"]; ?>">
								<i class='fas fa-trash' style='font-size:24px'></i>
                        		</a></td>
						      </tr>
						    </tbody>
  </table>
					</div>

				</div>
			</div>
			</form>
	</body>
</html>