<?php
  require_once "Header.php";

  session_start();
  ?>
  <?php
  // the function determines the current page URL
  function curPageURL() {
     $pageURL = 'http';
     if ($_SERVER["HTTPS"] == "on") {
       $pageURL .= "s";
     }
     $pageURL .= "://";

     if ($_SERVER["SERVER_PORT"] != "80") {
       $pageURL .= "localhost:".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
     } else {
       $pageURL .= "localhost".$_SERVER["REQUEST_URI"];
     }
     return $pageURL;
   }

 ?>


 <label style="font-size:20;"> Employee Details</label>
 <table  border=1 align=center width=500>
	<thead>
	  <tr>
		<th>Empname</th>
		<th>DOB</th>
		<th>Location</th>
		<th>Department</th>

	  </tr>
	</thead>
	<tbody>
	  <tr>
		<td>Priyanka</td>
		<td>12-03-2016</td>
		<td>Chennai</td>
		<td>Sales</td>

	  </tr>
	  <tr>
		<td>Sushant</td>
		<td>20-01-2017</td>
		<td>Mumbai</td>
		<td>IT</td>

	  </tr>
	  <tr>
		<td>Riya</td>
		<td>02-10-2019</td>
		<td>Mumbai</td>
		<td>IT</td>

	  </tr>
	</tbody>
</table>