<?PHP
      ob_start();
      include(dirname(__FILE__).'/Sampledata.php');
      $content = ob_get_clean();
      require_once(dirname(__FILE__).'/html2pdf_v4.01/html2pdf.class.php');
      try
	  {
	      	$html2pdf = new HTML2PDF(); // you can use the default parms
	      	$html2pdf->setDefaultFont('Arial');
     		$html2pdf->writeHTML($content);
     		ob_clean();
		    $html2pdf->Output('Sampledata.pdf');
      }
      catch(HTML2PDF_exception $e) { echo $e; }
?>