<?php
if(isset($_POST["query"]))
	{
		$searchData=$_POST["query"];
		$s=' ';$comma=' , ';
		if(strpos($searchData,' ') || strpos($searchData,','))
		{


			if(strpos($searchData,','))
			{
				$result=explode(',',$searchData);
				$s=',';
			}
			else
			{
				$result=explode(' ',$searchData);
				$s=' ';
			}
			$cnt=count($result);
			$c=$cnt-1;
			for($i=0;$i< count($result); $i++)
			{
				echo "1";
				$searchData=$result[$i];
				$txt.=" txt LIKE '%".$searchData."%'";
				for($j=$c;$j < count($result);$j++)
				{
					$txt.=" and";
				}

			}
			//$c=$c+1;
			$str= preg_replace('/\W\w+\s*(\W*)$/', '$1', $txt);
			$txt=$str;
		}
		else
		{
			$txt=" txt LIKE '%".$searchData."%'";
		}

//$select="select Empid,Empname,DOB,Location,Department from tblEmployee where * Like '%".$searchData."%' or City Like '$searchData' or Phone Like '$searchData' or Email Like '$searchData' or About Like '$searchData' or ClientList Like '$searchData'" ;
		$select="SELECT * FROM (SELECT *,CONCAT(Empname,'".$s."',DOB,'".$s."',Location,'".$s."',Department) txt
			FROM FormDetails) a
			WHERE ".$txt."
			ORDER BY Id ASC limit ".$row.",".$rowperpage;
//echo $select;
		$query=mysql_query($select,$connection);
		if(!$query)
		{
			echo "not selected";

		}
		echo "<div class='row'>";
		while($row= mysql_fetch_row($query))
		{
			echo "<div class='col-md-4'>";

			echo $DOB=$row[2];
			echo "<legend><img id='imgdata' src='Designer_images/$photo'/></legend><br>";
			//echo "Searched Data=".$searchData;
			echo $username=$row[1]."<br>";
			echo $Location=$row[3]."<br>";
			echo $Dept=$row[4];


			echo "</div>";
		}
		echo "</div>";
?>